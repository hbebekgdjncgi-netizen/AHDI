"""يُشغَّل تلقائيًا أثناء البناء: يضيف صلاحيات الإشعارات وإعدادات أندرويد اللازمة."""
import pathlib
import re

# ── AndroidManifest.xml ──
m = pathlib.Path("android/app/src/main/AndroidManifest.xml")
t = m.read_text(encoding="utf-8")

perms = """    <uses-permission android:name="android.permission.POST_NOTIFICATIONS"/>
    <uses-permission android:name="android.permission.VIBRATE"/>
    <uses-permission android:name="android.permission.RECEIVE_BOOT_COMPLETED"/>
    <uses-permission android:name="android.permission.SCHEDULE_EXACT_ALARM"/>
"""
receivers = """        <receiver android:exported="false" android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationReceiver" />
        <receiver android:exported="false" android:name="com.dexterous.flutterlocalnotifications.ScheduledNotificationBootReceiver">
            <intent-filter>
                <action android:name="android.intent.action.BOOT_COMPLETED"/>
                <action android:name="android.intent.action.MY_PACKAGE_REPLACED"/>
                <action android:name="android.intent.action.QUICKBOOT_POWERON"/>
                <action android:name="com.htc.intent.action.QUICKBOOT_POWERON"/>
            </intent-filter>
        </receiver>
"""
if "POST_NOTIFICATIONS" not in t:
    t = t.replace("<application", perms + "    <application", 1)
    t = t.replace("</application>", receivers + "    </application>", 1)
t = re.sub(r'android:label="[^"]*"', 'android:label="دعاء العهد"', t, count=1)
m.write_text(t, encoding="utf-8")

# ── build.gradle(.kts): تفعيل desugaring المطلوب لمكتبة الإشعارات ──
kts = pathlib.Path("android/app/build.gradle.kts")
groovy = pathlib.Path("android/app/build.gradle")
DESUGAR = "com.android.tools:desugar_jdk_libs:2.1.4"

if kts.exists():
    g = kts.read_text(encoding="utf-8")
    g = g.replace("compileOptions {", "compileOptions {\n        isCoreLibraryDesugaringEnabled = true", 1)
    g += f'\ndependencies {{\n    coreLibraryDesugaring("{DESUGAR}")\n}}\n'
    kts.write_text(g, encoding="utf-8")
elif groovy.exists():
    g = groovy.read_text(encoding="utf-8")
    g = g.replace("compileOptions {", "compileOptions {\n        coreLibraryDesugaringEnabled true", 1)
    g += f"\ndependencies {{\n    coreLibraryDesugaring '{DESUGAR}'\n}}\n"
    groovy.write_text(g, encoding="utf-8")
else:
    raise SystemExit("لم يُعثر على ملف build.gradle")

print("patched OK")
