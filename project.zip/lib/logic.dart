// منطق العدّادات والفترات (بدون أي اعتماد على واجهة أو نظام تشغيل، ليسهل اختباره).

const appVersion = '1.0.0';
const achievementDays = [7, 30, 40, 100, 365];

enum ReadResult { morning, late, already }

String dayKey(DateTime d) =>
    '${d.year.toString().padLeft(4, '0')}-${d.month.toString().padLeft(2, '0')}-${d.day.toString().padLeft(2, '0')}';

DateTime parseKey(String k) {
  final p = k.split('-');
  return DateTime(int.parse(p[0]), int.parse(p[1]), int.parse(p[2]));
}

DateTime addDays(DateTime d, int n) => DateTime(d.year, d.month, d.day + n);

class Settings {
  int startMin; // دقائق منذ منتصف الليل
  int endMin;
  int interval; // 15 أو 30 أو 60
  bool notif;
  bool dark;
  bool vibrate;
  double fontSize;
  String? muteUntil; // آخر يوم كتم (شامل) بصيغة yyyy-MM-dd

  Settings({
    this.startMin = 300,
    this.endMin = 660,
    this.interval = 30,
    this.notif = true,
    this.dark = false,
    this.vibrate = true,
    this.fontSize = 24,
    this.muteUntil,
  });

  Map<String, dynamic> toJson() => {
        'startMin': startMin,
        'endMin': endMin,
        'interval': interval,
        'notif': notif,
        'dark': dark,
        'vibrate': vibrate,
        'fontSize': fontSize,
        'muteUntil': muteUntil,
      };

  factory Settings.fromJson(Map<String, dynamic> j) => Settings(
        startMin: (j['startMin'] ?? 300) as int,
        endMin: (j['endMin'] ?? 660) as int,
        interval: (j['interval'] ?? 30) as int,
        notif: (j['notif'] ?? true) as bool,
        dark: (j['dark'] ?? false) as bool,
        vibrate: (j['vibrate'] ?? true) as bool,
        fontSize: ((j['fontSize'] ?? 24) as num).toDouble(),
        muteUntil: j['muteUntil'] as String?,
      );
}

class AppData {
  Set<String> morning; // أيام القراءة الصباحية (تُحتسب)
  Set<String> lates; // أيام القراءة المتأخرة (لا تُحتسب)
  String? firstUse;
  Settings settings;

  AppData({Set<String>? morning, Set<String>? lates, this.firstUse, Settings? settings})
      : morning = morning ?? <String>{},
        lates = lates ?? <String>{},
        settings = settings ?? Settings();

  Map<String, dynamic> toJson() => {
        'v': 1,
        'morning': morning.toList()..sort(),
        'lates': lates.toList()..sort(),
        'firstUse': firstUse,
        'settings': settings.toJson(),
      };

  factory AppData.fromJson(Map<String, dynamic> j) {
    final m = Set<String>.from((j['morning'] ?? const []) as List);
    final l = Set<String>.from((j['lates'] ?? const []) as List);
    for (final k in [...m, ...l]) {
      parseKey(k); // يرمي خطأ إن كان التاريخ غير صالح
    }
    return AppData(
      morning: m,
      lates: l,
      firstUse: j['firstUse'] as String?,
      settings: Settings.fromJson(Map<String, dynamic>.from((j['settings'] ?? {}) as Map)),
    );
  }

  /// دمج نسخة احتياطية: لا يُفقد أي يوم مسجّل.
  void mergeFrom(AppData o) {
    morning.addAll(o.morning);
    lates.addAll(o.lates);
    if (o.firstUse != null && (firstUse == null || o.firstUse!.compareTo(firstUse!) < 0)) {
      firstUse = o.firstUse;
    }
  }
}

bool hasEnded(DateTime now, int endMin) =>
    !now.isBefore(DateTime(now.year, now.month, now.day, endMin ~/ 60, endMin % 60));

/// تسجيل قراءة. مرة واحدة فقط في اليوم مهما تكرر الضغط.
ReadResult recordRead(AppData d, DateTime now) {
  final k = dayKey(now);
  d.firstUse ??= k;
  if (d.morning.contains(k) || d.lates.contains(k)) return ReadResult.already;
  if (hasEnded(now, d.settings.endMin)) {
    d.lates.add(k);
    return ReadResult.late;
  }
  d.morning.add(k);
  return ReadResult.morning;
}

/// السلسلة الحالية تُحسب من التواريخ المسجّلة نفسها، فلا تتأثر بإغلاق التطبيق
/// أو عدم فتحه أياماً، ولا يمكن أن تزيد مرتين في اليوم.
int currentStreak(Set<String> morning, DateTime now, int endMin) {
  var day = DateTime(now.year, now.month, now.day);
  if (!morning.contains(dayKey(day))) {
    if (hasEnded(now, endMin)) return 0; // انتهت فترة اليوم دون قراءة
    day = addDays(day, -1); // اليوم ما زال مفتوحاً، تُحسب السلسلة حتى أمس
  }
  var n = 0;
  while (morning.contains(dayKey(day))) {
    n++;
    day = addDays(day, -1);
  }
  return n;
}

class Run {
  final DateTime start, end;
  final int len;
  const Run(this.start, this.end, this.len);
}

List<Run> runsOf(Set<String> morning) {
  final days = morning.map(parseKey).toList()..sort();
  final out = <Run>[];
  if (days.isEmpty) return out;
  var s = days.first, p = days.first, n = 1;
  for (final d in days.skip(1)) {
    if (d == addDays(p, 1)) {
      p = d;
      n++;
    } else {
      out.add(Run(s, p, n));
      s = d;
      p = d;
      n = 1;
    }
  }
  out.add(Run(s, p, n));
  return out;
}

/// الرقم القياسي: أطول سلسلة في كل السجل، ولا ينخفض أبداً.
int longestStreak(Set<String> morning) =>
    runsOf(morning).fold(0, (a, r) => r.len > a ? r.len : a);

double adherence(AppData d, DateTime now, int days) {
  final first = parseKey(d.firstUse ?? dayKey(now));
  final since = DateTime.utc(now.year, now.month, now.day)
          .difference(DateTime.utc(first.year, first.month, first.day))
          .inDays +
      1;
  final window = since < 1 ? 1 : (since < days ? since : days);
  var c = 0;
  for (var i = 0; i < window; i++) {
    if (d.morning.contains(dayKey(addDays(now, -i)))) c++;
  }
  return c / window;
}

bool isMuted(Settings s, String key) => s.muteUntil != null && key.compareTo(s.muteUntil!) <= 0;

/// أوقات التذكير في يوم معيّن: من بداية الفترة وحتى قبل نهايتها (النهاية غير مشمولة).
List<DateTime> slotsForDay(DateTime day, Settings s) {
  final out = <DateTime>[];
  for (var t = s.startMin; t < s.endMin; t += s.interval) {
    out.add(DateTime(day.year, day.month, day.day, t ~/ 60, t % 60));
  }
  return out;
}

DateTime? nextReminder(AppData d, DateTime now) {
  if (!d.settings.notif) return null;
  for (var off = 0; off < 3; off++) {
    final day = addDays(now, off);
    final key = dayKey(day);
    if (off == 0 && (d.morning.contains(key) || d.lates.contains(key))) continue;
    if (isMuted(d.settings, key)) continue;
    for (final t in slotsForDay(day, d.settings)) {
      if (t.isAfter(now)) return t;
    }
  }
  return null;
}
