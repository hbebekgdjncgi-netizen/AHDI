import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:flutter_timezone/flutter_timezone.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:timezone/data/latest.dart' as tzdata;
import 'package:timezone/timezone.dart' as tz;

import 'dua_text.dart';
import 'logic.dart';

// ───────────── أدوات عرض ─────────────
String ar(Object n) {
  const d = '٠١٢٣٤٥٦٧٨٩';
  return n.toString().split('').map((c) {
    final i = int.tryParse(c);
    return i == null ? c : d[i];
  }).join();
}

const _weekdays = ['الإثنين', 'الثلاثاء', 'الأربعاء', 'الخميس', 'الجمعة', 'السبت', 'الأحد'];
const _months = [
  'يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو',
  'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'
];

String fmtDate(DateTime d) => '${_weekdays[d.weekday - 1]}، ${ar(d.day)} ${_months[d.month - 1]} ${ar(d.year)}';
String fmtShort(DateTime d) => '${ar(d.day)} ${_months[d.month - 1]} ${ar(d.year)}';

String fmtTime(int m) {
  final h = m ~/ 60, mm = m % 60;
  final h12 = h % 12 == 0 ? 12 : h % 12;
  return '${ar(h12)}:${ar(mm.toString().padLeft(2, '0'))} ${h < 12 ? 'ص' : 'م'}';
}

String fmtDT(DateTime t) => fmtTime(t.hour * 60 + t.minute);

// ───────────── الإشعارات المحلية ─────────────
final ValueNotifier<int> tabIndex = ValueNotifier<int>(0);

class Notifier {
  static final FlutterLocalNotificationsPlugin _p = FlutterLocalNotificationsPlugin();
  static const _msgs = [
    'لا تنسَ قراءة دعاء العهد لهذا الصباح 🌿',
    'صباحٌ مبارك، دعاء العهد بانتظارك 🌿',
    'لحظات هادئة مع دعاء العهد متى تيسّر لك 🌿',
    'تذكير لطيف بدعاء العهد لهذا الصباح 🌿',
  ];

  static AndroidFlutterLocalNotificationsPlugin? get _android =>
      _p.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>();

  static Future<void> init() async {
    tzdata.initializeTimeZones();
    try {
      final name = await FlutterTimezone.getLocalTimezone();
      tz.setLocalLocation(tz.getLocation(name));
    } catch (_) {}
    await _p.initialize(
      const InitializationSettings(android: AndroidInitializationSettings('@mipmap/ic_launcher')),
      onDidReceiveNotificationResponse: (_) => tabIndex.value = 1, // صفحة الدعاء
    );
    final launch = await _p.getNotificationAppLaunchDetails();
    if (launch?.didNotificationLaunchApp ?? false) tabIndex.value = 1;
  }

  static Future<bool> enabled() async {
    try {
      return await _android?.areNotificationsEnabled() ?? false;
    } catch (_) {
      return false;
    }
  }

  static Future<void> requestPermissions() async {
    try {
      await _android?.requestNotificationsPermission();
      final exact = await _android?.canScheduleExactNotifications() ?? true;
      if (!exact) await _android?.requestExactAlarmsPermission();
    } catch (_) {}
  }

  /// يجدول تذكيرات اليوم والغد وبعد غد، ويُعاد الجدولة عند كل فتح للتطبيق أو تغيير إعداد.
  static Future<void> reschedule(AppData d) async {
    try {
      await _p.cancelAll();
      if (!d.settings.notif) return;
      final exact = await _android?.canScheduleExactNotifications() ?? false;
      final mode = exact ? AndroidScheduleMode.exactAllowWhileIdle : AndroidScheduleMode.inexactAllowWhileIdle;
      final details = NotificationDetails(
        android: AndroidNotificationDetails(
          d.settings.vibrate ? 'reminders_v' : 'reminders_q',
          'تذكير دعاء العهد',
          channelDescription: 'تذكير صباحي هادئ بقراءة دعاء العهد',
          importance: Importance.high,
          priority: Priority.high,
          enableVibration: d.settings.vibrate,
        ),
      );
      final now = DateTime.now();
      for (var off = 0; off < 3; off++) {
        final day = addDays(now, off);
        final key = dayKey(day);
        if (off == 0 && (d.morning.contains(key) || d.lates.contains(key))) continue;
        if (isMuted(d.settings, key)) continue;
        for (final t in slotsForDay(day, d.settings)) {
          if (!t.isAfter(now)) continue;
          final id = off * 1000 + (t.hour * 60 + t.minute) ~/ 5;
          await _p.zonedSchedule(
            id,
            'دعاء العهد',
            _msgs[id % _msgs.length],
            tz.TZDateTime(tz.local, t.year, t.month, t.day, t.hour, t.minute),
            details,
            androidScheduleMode: mode,
            uiLocalNotificationDateInterpretation: UILocalNotificationDateInterpretation.absoluteTime,
            payload: 'dua',
          );
        }
      }
    } catch (e) {
      debugPrint('reschedule failed: $e');
    }
  }
}

// ───────────── الحالة والحفظ المحلي ─────────────
class Controller extends ChangeNotifier with WidgetsBindingObserver {
  AppData data = AppData();
  bool notifOk = true;
  Timer? _timer;

  Future<void> load() async {
    final p = await SharedPreferences.getInstance();
    final s = p.getString('state_v1');
    if (s != null) {
      try {
        data = AppData.fromJson(jsonDecode(s) as Map<String, dynamic>);
      } catch (_) {}
    }
    data.firstUse ??= dayKey(DateTime.now());
    if (p.getBool('asked') != true) {
      await Notifier.requestPermissions();
      await p.setBool('asked', true);
    }
    await _save();
    WidgetsBinding.instance.addObserver(this);
    _timer = Timer.periodic(const Duration(seconds: 30), (_) => notifyListeners());
    await _refresh();
  }

  Future<void> _save() async {
    final p = await SharedPreferences.getInstance();
    await p.setString('state_v1', jsonEncode(data.toJson()));
  }

  Future<void> _refresh() async {
    await Notifier.reschedule(data);
    notifOk = await Notifier.enabled();
    notifyListeners();
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    if (state == AppLifecycleState.resumed) _refresh();
  }

  Future<void> update(void Function() change) async {
    change();
    await _save();
    await _refresh();
  }

  Future<ReadResult> markRead() async {
    late ReadResult r;
    await update(() => r = recordRead(data, DateTime.now()));
    return r;
  }

  Future<void> askPermission() async {
    await Notifier.requestPermissions();
    await _refresh();
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }
}

// ───────────── الواجهة ─────────────
Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Notifier.init();
  final c = Controller();
  await c.load();
  runApp(DuaApp(c));
}

ThemeData buildTheme(bool dark) {
  const green = Color(0xFF1F4D3A), gold = Color(0xFFC8A96A);
  final scheme = dark
      ? const ColorScheme.dark(
          primary: gold,
          onPrimary: Color(0xFF1A1A1A),
          secondary: gold,
          surface: Color(0xFF16231C),
          onSurface: Color(0xFFEDE6D3))
      : const ColorScheme.light(
          primary: green,
          onPrimary: Colors.white,
          secondary: gold,
          surface: Colors.white,
          onSurface: Color(0xFF22302A));
  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    scaffoldBackgroundColor: dark ? const Color(0xFF0F1913) : const Color(0xFFF6F0E2),
    appBarTheme: AppBarTheme(
      backgroundColor: Colors.transparent,
      elevation: 0,
      foregroundColor: scheme.onSurface,
      centerTitle: true,
    ),
    navigationBarTheme: NavigationBarThemeData(
      backgroundColor: scheme.surface,
      indicatorColor: gold.withOpacity(0.35),
    ),
  );
}

class DuaApp extends StatelessWidget {
  final Controller c;
  const DuaApp(this.c, {super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: c,
      builder: (context, _) => MaterialApp(
        title: 'دعاء العهد',
        debugShowCheckedModeBanner: false,
        locale: const Locale('ar'),
        supportedLocales: const [Locale('ar')],
        localizationsDelegates: const [
          GlobalMaterialLocalizations.delegate,
          GlobalWidgetsLocalizations.delegate,
          GlobalCupertinoLocalizations.delegate,
        ],
        theme: buildTheme(c.data.settings.dark),
        home: Shell(c),
      ),
    );
  }
}

class Shell extends StatelessWidget {
  final Controller c;
  const Shell(this.c, {super.key});

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<int>(
      valueListenable: tabIndex,
      builder: (context, i, _) {
        final pages = [HomePage(c), DuaPage(c), HistoryPage(c), SettingsPage(c)];
        return Scaffold(
          body: SafeArea(child: pages[i]),
          bottomNavigationBar: NavigationBar(
            selectedIndex: i,
            onDestinationSelected: (v) => tabIndex.value = v,
            destinations: const [
              NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'الرئيسية'),
              NavigationDestination(icon: Icon(Icons.menu_book_outlined), selectedIcon: Icon(Icons.menu_book), label: 'الدعاء'),
              NavigationDestination(icon: Icon(Icons.calendar_month_outlined), selectedIcon: Icon(Icons.calendar_month), label: 'السجل'),
              NavigationDestination(icon: Icon(Icons.settings_outlined), selectedIcon: Icon(Icons.settings), label: 'الإعدادات'),
            ],
          ),
        );
      },
    );
  }
}

void snack(BuildContext context, String msg) {
  ScaffoldMessenger.of(context)
    ..clearSnackBars()
    ..showSnackBar(SnackBar(content: Text(msg), behavior: SnackBarBehavior.floating));
}

Future<void> doRead(BuildContext context, Controller c) async {
  final r = await c.markRead();
  if (!context.mounted) return;
  switch (r) {
    case ReadResult.morning:
      snack(context, 'تقبّل الله قراءتك، أحسنت المحافظة على عهدك 🌿');
    case ReadResult.late:
      snack(context, 'سُجّلت قراءتك. لم تدخل في سلسلة الصباح، وغدًا بداية طيبة بإذن الله 🌿');
    case ReadResult.already:
      snack(context, 'قراءة اليوم مسجّلة من قبل 🌿');
  }
}

// ───────────── الرئيسية ─────────────
class HomePage extends StatelessWidget {
  final Controller c;
  const HomePage(this.c, {super.key});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final d = c.data;
    final now = DateTime.now();
    final key = dayKey(now);
    final read = d.morning.contains(key);
    final lateRead = d.lates.contains(key);
    final ended = hasEnded(now, d.settings.endMin);
    final streak = currentStreak(d.morning, now, d.settings.endMin);
    final best = longestStreak(d.morning);
    final next = nextReminder(d, now);

    String status;
    if (read) {
      status = 'تمت القراءة ✓';
    } else if (lateRead) {
      status = 'قُرئ متأخرًا (خارج فترة الصباح)';
    } else if (ended) {
      status = 'انتهت فترة الصباح — يمكنك تسجيل قراءة متأخرة';
    } else {
      status = 'لم تُقرأ بعد';
    }

    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        Center(child: Text('دعاء العهد', style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold, color: cs.primary))),
        const SizedBox(height: 6),
        Center(child: Text('صباحك نور، حيّاك الله 🌿', style: TextStyle(fontSize: 16, color: cs.onSurface.withOpacity(0.75)))),
        const SizedBox(height: 4),
        Center(child: Text(fmtDate(now), style: TextStyle(color: cs.onSurface.withOpacity(0.6)))),
        const SizedBox(height: 20),
        if (d.settings.notif && !c.notifOk) _notifBanner(context),
        Container(
          padding: const EdgeInsets.symmetric(vertical: 26),
          decoration: BoxDecoration(color: cs.surface, borderRadius: BorderRadius.circular(24)),
          child: Column(children: [
            Text('سلسلة القراءة الحالية', style: TextStyle(color: cs.onSurface.withOpacity(0.7))),
            Text(ar(streak), style: TextStyle(fontSize: 64, fontWeight: FontWeight.bold, color: cs.primary)),
            Text(streak == 1 ? 'يوم' : 'أيام متتالية', style: TextStyle(color: cs.onSurface.withOpacity(0.7))),
          ]),
        ),
        const SizedBox(height: 14),
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(24),
            gradient: const LinearGradient(colors: [Color(0xFFE6CF9A), Color(0xFFC8A96A)]),
          ),
          child: Row(children: [
            const Icon(Icons.workspace_premium, size: 40, color: Color(0xFF3B2E10)),
            const SizedBox(width: 14),
            const Expanded(child: Text('الرقم القياسي لأطول سلسلة', style: TextStyle(fontSize: 16, color: Color(0xFF3B2E10), fontWeight: FontWeight.w600))),
            Text('${ar(best)} ${best == 1 ? 'يوم' : 'يومًا'}', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Color(0xFF3B2E10))),
          ]),
        ),
        const SizedBox(height: 22),
        Center(child: Text(status, style: TextStyle(fontSize: 16, color: cs.onSurface))),
        const SizedBox(height: 12),
        SizedBox(
          height: 64,
          child: FilledButton(
            style: FilledButton.styleFrom(shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20))),
            onPressed: (read || lateRead) ? null : () => doRead(context, c),
            child: Text(
              (read || lateRead) ? 'تمت قراءة اليوم ✓' : (ended ? 'سجّل قراءة متأخرة' : 'قرأت دعاء العهد اليوم'),
              style: const TextStyle(fontSize: 19),
            ),
          ),
        ),
        const SizedBox(height: 10),
        OutlinedButton.icon(
          onPressed: () => tabIndex.value = 1,
          icon: const Icon(Icons.menu_book),
          label: const Text('الانتقال إلى نص الدعاء'),
          style: OutlinedButton.styleFrom(minimumSize: const Size.fromHeight(50)),
        ),
        const SizedBox(height: 16),
        if (next != null)
          Center(
            child: Text(
              'التذكير القادم: ${dayKey(next) == key ? 'اليوم' : 'غدًا'} ${fmtDT(next)}',
              style: TextStyle(color: cs.onSurface.withOpacity(0.6)),
            ),
          ),
      ],
    );
  }

  Widget _notifBanner(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: 14),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(color: const Color(0xFFFFF3D6), borderRadius: BorderRadius.circular(16)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text(
          'الإشعارات غير مفعّلة لدى النظام، فلن تصلك التذكيرات.\n'
          'لتفعيلها: الإعدادات ← التطبيقات ← دعاء العهد ← الإشعارات ← تشغيل.',
          style: TextStyle(color: Color(0xFF3B2E10)),
        ),
        TextButton(onPressed: c.askPermission, child: const Text('طلب الإذن الآن')),
      ]),
    );
  }
}

// ───────────── صفحة الدعاء ─────────────
class DuaPage extends StatelessWidget {
  final Controller c;
  const DuaPage(this.c, {super.key});

  @override
  Widget build(BuildContext context) {
    final s = c.data.settings;
    final d = c.data;
    final now = DateTime.now();
    final done = d.morning.contains(dayKey(now)) || d.lates.contains(dayKey(now));
    return Column(children: [
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 8),
        child: Row(children: [
          const SizedBox(width: 12),
          const Text('دعاء العهد', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          const Spacer(),
          IconButton(
            tooltip: 'تصغير الخط',
            icon: const Icon(Icons.text_decrease),
            onPressed: () => c.update(() => s.fontSize = (s.fontSize - 2).clamp(18, 44).toDouble()),
          ),
          IconButton(
            tooltip: 'تكبير الخط',
            icon: const Icon(Icons.text_increase),
            onPressed: () => c.update(() => s.fontSize = (s.fontSize + 2).clamp(18, 44).toDouble()),
          ),
          IconButton(
            tooltip: 'الوضع الليلي',
            icon: Icon(s.dark ? Icons.light_mode : Icons.dark_mode),
            onPressed: () => c.update(() => s.dark = !s.dark),
          ),
        ]),
      ),
      Expanded(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(22, 10, 22, 20),
          child: duaText.trim().isEmpty
              ? const Padding(
                  padding: EdgeInsets.only(top: 40),
                  child: Center(child: Text('لم يُضَف نص الدعاء إلى هذه النسخة بعد.')),
                )
              : SelectableText(
                  duaText.trim(),
                  textAlign: TextAlign.justify,
                  style: TextStyle(fontSize: s.fontSize, height: 2.0),
                ),
        ),
      ),
      Padding(
        padding: const EdgeInsets.fromLTRB(20, 4, 20, 12),
        child: SizedBox(
          height: 56,
          width: double.infinity,
          child: FilledButton(
            onPressed: done ? null : () => doRead(context, c),
            child: Text(done ? 'تمت قراءة اليوم ✓' : 'أتممت القراءة', style: const TextStyle(fontSize: 18)),
          ),
        ),
      ),
    ]);
  }
}

// ───────────── السجل والإحصائيات والإنجازات ─────────────
class HistoryPage extends StatefulWidget {
  final Controller c;
  const HistoryPage(this.c, {super.key});
  @override
  State<HistoryPage> createState() => _HistoryPageState();
}

class _HistoryPageState extends State<HistoryPage> {
  DateTime month = DateTime(DateTime.now().year, DateTime.now().month);

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final d = widget.c.data;
    final now = DateTime.now();
    final best = longestStreak(d.morning);
    final runs = runsOf(d.morning).reversed.take(8).toList();

    Widget statCard(String label, String value) => Expanded(
          child: Container(
            padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 8),
            decoration: BoxDecoration(color: cs.surface, borderRadius: BorderRadius.circular(16)),
            child: Column(children: [
              Text(value, style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: cs.primary)),
              const SizedBox(height: 4),
              Text(label, textAlign: TextAlign.center, style: const TextStyle(fontSize: 12)),
            ]),
          ),
        );

    return ListView(padding: const EdgeInsets.all(18), children: [
      Text('الإحصائيات', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: cs.primary)),
      const SizedBox(height: 10),
      Row(children: [
        statCard('مجموع القراءات', ar(d.morning.length + d.lates.length)),
        const SizedBox(width: 8),
        statCard('أيام الصباح', ar(d.morning.length)),
        const SizedBox(width: 8),
        statCard('أطول سلسلة', ar(best)),
      ]),
      const SizedBox(height: 8),
      Row(children: [
        statCard('الالتزام آخر ٧ أيام', '${ar((adherence(d, now, 7) * 100).round())}٪'),
        const SizedBox(width: 8),
        statCard('الالتزام آخر ٣٠ يومًا', '${ar((adherence(d, now, 30) * 100).round())}٪'),
      ]),
      const SizedBox(height: 22),
      Text('الإنجازات', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: cs.primary)),
      const SizedBox(height: 10),
      Wrap(spacing: 10, runSpacing: 10, children: [
        for (final n in achievementDays)
          Container(
            width: 96,
            padding: const EdgeInsets.symmetric(vertical: 12),
            decoration: BoxDecoration(
              color: best >= n ? const Color(0xFFE6CF9A) : cs.surface,
              borderRadius: BorderRadius.circular(16),
            ),
            child: Column(children: [
              Icon(best >= n ? Icons.workspace_premium : Icons.lock_outline,
                  color: best >= n ? const Color(0xFF3B2E10) : cs.onSurface.withOpacity(0.4)),
              Text('${ar(n)} يومًا',
                  style: TextStyle(fontWeight: FontWeight.w600, color: best >= n ? const Color(0xFF3B2E10) : cs.onSurface.withOpacity(0.6))),
            ]),
          ),
      ]),
      const SizedBox(height: 22),
      Text('السجل', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: cs.primary)),
      Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        IconButton(onPressed: () => setState(() => month = DateTime(month.year, month.month + 1)), icon: const Icon(Icons.chevron_right)),
        Text('${_months[month.month - 1]} ${ar(month.year)}', style: const TextStyle(fontSize: 17)),
        IconButton(onPressed: () => setState(() => month = DateTime(month.year, month.month - 1)), icon: const Icon(Icons.chevron_left)),
      ]),
      _calendar(context, d, now),
      const SizedBox(height: 10),
      Wrap(spacing: 14, children: [
        _legend(cs.primary, 'قراءة صباحية', filled: true),
        _legend(const Color(0xFFC8A96A), 'قراءة متأخرة'),
        _legend(cs.onSurface.withOpacity(0.25), 'يوم فائت', filled: true),
      ]),
      const SizedBox(height: 22),
      Text('سلاسل القراءة', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: cs.primary)),
      const SizedBox(height: 8),
      if (runs.isEmpty) const Text('ستظهر هنا بدايات سلاسلك بعد أول قراءة صباحية.'),
      for (final r in runs)
        ListTile(
          dense: true,
          leading: const Icon(Icons.local_fire_department_outlined),
          title: Text('بدأت في ${fmtShort(r.start)}'),
          subtitle: Text('${ar(r.len)} ${r.len == 1 ? 'يوم' : 'يومًا'} — حتى ${fmtShort(r.end)}'),
        ),
    ]);
  }

  Widget _legend(Color col, String t, {bool filled = false}) => Row(mainAxisSize: MainAxisSize.min, children: [
        Container(
          width: 14,
          height: 14,
          decoration: BoxDecoration(
              shape: BoxShape.circle, color: filled ? col : null, border: filled ? null : Border.all(color: col, width: 2)),
        ),
        const SizedBox(width: 6),
        Text(t, style: const TextStyle(fontSize: 12)),
      ]);

  Widget _calendar(BuildContext context, AppData d, DateTime now) {
    final cs = Theme.of(context).colorScheme;
    final offset = DateTime(month.year, month.month, 1).weekday % 7; // الأحد = 0
    final count = DateTime(month.year, month.month + 1, 0).day;
    final today = DateTime(now.year, now.month, now.day);
    final first = parseKey(d.firstUse ?? dayKey(now));
    final names = ['أحد', 'إثنين', 'ثلاثاء', 'أربعاء', 'خميس', 'جمعة', 'سبت'];
    final cells = <Widget>[for (final n in names) Center(child: Text(n, style: const TextStyle(fontSize: 11)))];
    for (var i = 0; i < offset; i++) {
      cells.add(const SizedBox());
    }
    for (var day = 1; day <= count; day++) {
      final dt = DateTime(month.year, month.month, day);
      final k = dayKey(dt);
      final m = d.morning.contains(k), l = d.lates.contains(k);
      final isToday = dt == today;
      final past = dt.isBefore(today) || (isToday && hasEnded(now, d.settings.endMin));
      final missed = !m && !l && past && !dt.isBefore(first);
      Color? fill;
      Border? border;
      Color txt = cs.onSurface;
      if (m) {
        fill = cs.primary;
        txt = cs.onPrimary;
      } else if (l) {
        border = Border.all(color: const Color(0xFFC8A96A), width: 2);
      } else if (missed) {
        fill = cs.onSurface.withOpacity(0.12);
      }
      if (isToday && border == null && !m) border = Border.all(color: cs.primary, width: 1.5);
      cells.add(Container(
        margin: const EdgeInsets.all(3),
        decoration: BoxDecoration(shape: BoxShape.circle, color: fill, border: border),
        alignment: Alignment.center,
        child: Text(ar(day), style: TextStyle(fontSize: 13, color: txt)),
      ));
    }
    return GridView.count(
      crossAxisCount: 7,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      children: cells,
    );
  }
}

// ───────────── الإعدادات ─────────────
class SettingsPage extends StatelessWidget {
  final Controller c;
  const SettingsPage(this.c, {super.key});

  Future<void> _pick(BuildContext context, bool start) async {
    final s = c.data.settings;
    final cur = start ? s.startMin : s.endMin;
    final t = await showTimePicker(context: context, initialTime: TimeOfDay(hour: cur ~/ 60, minute: cur % 60));
    if (t == null || !context.mounted) return;
    final m = t.hour * 60 + t.minute;
    final ns = start ? m : s.startMin;
    final ne = start ? s.endMin : m;
    if (ns >= ne) {
      snack(context, 'يجب أن تكون بداية الفترة قبل نهايتها (ضمن اليوم نفسه).');
      return;
    }
    await c.update(() {
      if (start) {
        s.startMin = m;
      } else {
        s.endMin = m;
      }
    });
  }

  Future<void> _import(BuildContext context) async {
    final ctl = TextEditingController();
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('استعادة نسخة احتياطية'),
        content: TextField(controller: ctl, maxLines: 6, decoration: const InputDecoration(hintText: 'ألصق النص المنسوخ هنا')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('إلغاء')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('استعادة')),
        ],
      ),
    );
    if (ok != true || !context.mounted) return;
    try {
      final imported = AppData.fromJson(jsonDecode(ctl.text.trim()) as Map<String, dynamic>);
      await c.update(() => c.data.mergeFrom(imported));
      if (context.mounted) snack(context, 'تمت الاستعادة ودمج السجل بنجاح 🌿');
    } catch (_) {
      if (context.mounted) snack(context, 'النص غير صالح كنسخة احتياطية.');
    }
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final s = c.data.settings;
    final today = DateTime.now();
    final muted = isMuted(s, dayKey(today));
    Widget title(String t) => Padding(
          padding: const EdgeInsets.only(top: 18, bottom: 4),
          child: Text(t, style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: cs.primary)),
        );
    return ListView(padding: const EdgeInsets.all(16), children: [
      Text('الإعدادات', style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: cs.primary)),
      title('فترة الصباح'),
      ListTile(title: const Text('بداية الفترة'), trailing: Text(fmtTime(s.startMin)), onTap: () => _pick(context, true)),
      ListTile(title: const Text('نهاية الفترة'), trailing: Text(fmtTime(s.endMin)), onTap: () => _pick(context, false)),
      title('التذكيرات'),
      SwitchListTile(
        title: const Text('تشغيل التذكيرات'),
        value: s.notif,
        onChanged: (v) async {
          await c.update(() => s.notif = v);
          if (v) await c.askPermission();
        },
      ),
      ListTile(
        title: const Text('التكرار كل'),
        subtitle: SegmentedButton<int>(
          segments: const [
            ButtonSegment(value: 15, label: Text('١٥ دقيقة')),
            ButtonSegment(value: 30, label: Text('٣٠ دقيقة')),
            ButtonSegment(value: 60, label: Text('٦٠ دقيقة')),
          ],
          selected: {s.interval},
          onSelectionChanged: (v) => c.update(() => s.interval = v.first),
        ),
      ),
      SwitchListTile(title: const Text('الاهتزاز عند الإشعار'), value: s.vibrate, onChanged: (v) => c.update(() => s.vibrate = v)),
      ListTile(
        title: Text(muted ? 'الكتم مفعّل حتى ${fmtShort(parseKey(s.muteUntil!))}' : 'كتم مؤقت للتذكيرات'),
        subtitle: Wrap(spacing: 8, children: [
          ActionChip(label: const Text('اليوم'), onPressed: () => c.update(() => s.muteUntil = dayKey(today))),
          ActionChip(label: const Text('٣ أيام'), onPressed: () => c.update(() => s.muteUntil = dayKey(addDays(today, 2)))),
          if (s.muteUntil != null) ActionChip(label: const Text('إلغاء الكتم'), onPressed: () => c.update(() => s.muteUntil = null)),
        ]),
      ),
      title('المظهر'),
      SwitchListTile(title: const Text('الوضع الليلي'), value: s.dark, onChanged: (v) => c.update(() => s.dark = v)),
      ListTile(
        title: Text('حجم خط الدعاء: ${ar(s.fontSize.round())}'),
        subtitle: Slider(value: s.fontSize, min: 18, max: 44, divisions: 13, onChanged: (v) => c.update(() => s.fontSize = v)),
      ),
      title('النسخ الاحتياطي'),
      ListTile(
        leading: const Icon(Icons.copy),
        title: const Text('نسخ بياناتي'),
        subtitle: const Text('يُنسخ نص يمكنك حفظه في ملاحظاتك'),
        onTap: () async {
          await Clipboard.setData(ClipboardData(text: jsonEncode(c.data.toJson())));
          if (context.mounted) snack(context, 'تم النسخ. احفظه في مكان آمن 🌿');
        },
      ),
      ListTile(leading: const Icon(Icons.download), title: const Text('استعادة نسخة'), onTap: () => _import(context)),
      title('عن التطبيق'),
      const ListTile(title: Text('إصدار التطبيق'), trailing: Text(appVersion)),
    ]);
  }
}
