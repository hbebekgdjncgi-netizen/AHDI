import 'dart:convert';

import 'package:dua_ahd/logic.dart';
import 'package:flutter_test/flutter_test.dart';

DateTime at(int day, int h, [int m = 0, int s = 0]) => DateTime(2026, 3, day, h, m, s);

void main() {
  const end = 660; // 11:00

  test('السيناريو الأساسي: ٣ أيام ثم انقطاع ثم بداية جديدة والرقم القياسي يبقى', () {
    final d = AppData();
    for (var day = 1; day <= 3; day++) {
      expect(recordRead(d, at(day, 8)), ReadResult.morning);
    }
    expect(currentStreak(d.morning, at(3, 9), end), 3);
    // اليوم الرابع: انتهت الفترة دون قراءة
    expect(currentStreak(d.morning, at(4, 11, 1), end), 0);
    expect(longestStreak(d.morning), 3);
    // اليوم الخامس
    recordRead(d, at(5, 8));
    expect(currentStreak(d.morning, at(5, 8, 1), end), 1);
    expect(longestStreak(d.morning), 3);
    for (var day = 6; day <= 9; day++) {
      recordRead(d, at(day, 8));
    }
    expect(currentStreak(d.morning, at(9, 9), end), 5);
    expect(longestStreak(d.morning), 5);
  });

  test('لا يُصفَّر العدّاد قبل انتهاء فترة الصباح', () {
    final d = AppData();
    for (var day = 1; day <= 3; day++) {
      recordRead(d, at(day, 8));
    }
    expect(currentStreak(d.morning, at(4, 6), end), 3);
    expect(currentStreak(d.morning, at(4, 10, 59, 59), end), 3);
    expect(currentStreak(d.morning, at(4, 11), end), 0);
  });

  test('الضغط المتكرر في اليوم نفسه يحتسب مرة واحدة', () {
    final d = AppData();
    expect(recordRead(d, at(1, 8)), ReadResult.morning);
    expect(recordRead(d, at(1, 8, 5)), ReadResult.already);
    expect(recordRead(d, at(1, 9)), ReadResult.already);
    expect(currentStreak(d.morning, at(1, 9), end), 1);
    expect(d.morning.length, 1);
  });

  test('آخر دقيقة تُحتسب، وبعد الانتهاء تُسجَّل متأخرة ولا تدخل السلسلة', () {
    final a = AppData();
    expect(recordRead(a, at(1, 10, 59, 59)), ReadResult.morning);
    final b = AppData();
    expect(recordRead(b, at(1, 11, 0, 0)), ReadResult.late);
    expect(b.morning, isEmpty);
    expect(b.lates.length, 1);
    expect(currentStreak(b.morning, at(1, 12), end), 0);
  });

  test('عدم فتح التطبيق عدة أيام', () {
    final d = AppData();
    recordRead(d, at(1, 8));
    recordRead(d, at(2, 8));
    expect(currentStreak(d.morning, at(7, 8), end), 0);
    expect(longestStreak(d.morning), 2);
  });

  test('قراءة متأخرة أمس لا تمنع سلسلة جديدة اليوم', () {
    final d = AppData();
    recordRead(d, at(1, 12)); // متأخرة
    recordRead(d, at(2, 8));
    expect(currentStreak(d.morning, at(2, 9), end), 1);
  });

  test('أوقات التذكير: النهاية غير مشمولة', () {
    final s = Settings(startMin: 300, endMin: 360, interval: 30);
    final slots = slotsForDay(at(1, 0), s);
    expect(slots.length, 2);
    expect(slots.first, at(1, 5));
    expect(slots.last, at(1, 5, 30));
    expect(slotsForDay(at(1, 0), Settings(startMin: 300, endMin: 660, interval: 15)).length, 24);
  });

  test('التذكير القادم يتوقف بعد القراءة ويحترم الكتم', () {
    final d = AppData();
    expect(nextReminder(d, at(1, 5, 10)), at(1, 5, 30));
    recordRead(d, at(1, 5, 20));
    expect(nextReminder(d, at(1, 5, 21)), at(2, 5));
    d.settings.muteUntil = dayKey(at(2, 0));
    expect(nextReminder(d, at(1, 5, 21)), at(3, 5));
    d.settings.notif = false;
    expect(nextReminder(d, at(1, 5, 21)), isNull);
  });

  test('النسخ الاحتياطي: تصدير ثم استعادة ودمج', () {
    final d = AppData();
    recordRead(d, at(1, 8));
    recordRead(d, at(2, 12));
    final copy = AppData.fromJson(jsonDecode(jsonEncode(d.toJson())) as Map<String, dynamic>);
    expect(copy.morning, d.morning);
    expect(copy.lates, d.lates);
    final fresh = AppData()..mergeFrom(copy);
    expect(fresh.morning, d.morning);
    expect(fresh.firstUse, d.firstUse);
  });

  test('نسبة الالتزام', () {
    final d = AppData();
    recordRead(d, at(1, 8));
    recordRead(d, at(2, 8));
    expect(adherence(d, at(2, 9), 7), 1.0);
    expect(adherence(d, at(4, 9), 7), 0.5);
  });

  test('تغيير فترة الصباح يطبَّق على الحاضر فقط', () {
    final d = AppData();
    d.settings.endMin = 600; // 10:00
    expect(recordRead(d, at(1, 10, 30)), ReadResult.late);
  });
}
